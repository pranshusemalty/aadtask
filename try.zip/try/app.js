var express =require("express");
var mongoose =require("mongoose");
var bodyparser =require("body-parser");
const cron = require("node-cron");
const shell =require("shelljs")

//cron.schedule("* * * * * * ",function(err){
//    blogapp.find().then(result=>{
        
        
//    })

//})


var app =express();

app.use(bodyparser.urlencoded({extended:true}));

 mongoose.connect('mongodb+srv://user:12345@cluster0.0bz4o.mongodb.net/blogapp?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
},(err)=>{
if(err)
{
    console.log(err);
}
else{
    console.log("connected");
}
});


////
//var today = new Date();
//var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
//var dateTime = time;
//console.log(dateTime);
/////schema

var blogschema =mongoose.Schema({
    taskname:String,
    taskdesc:String,
    creator:String,
    duration: Number,
},{timestamps:true});

var blogapp =mongoose.model("blogapp",blogschema);

///////routes
app.get("/",(req,res)=>{
    res.redirect("/add");
})


app.get("/add",(req,res)=>{
   res.render("addtask.ejs");
})

app.post("/check",(req,res)=>{
    
    blogapp.create(req.body.raw,function(err,blogapp){
        if(err){
            res.send("error");
        }
        else{
            res.redirect("/add");
        }
    });







 })
 app.get("/list",(req,res)=>{

blogapp.find().then(result=>{
    res.json({data:result}).pretty();
})

 });

app.listen(process.env.PORT||8000,()=>{
    console.log("connected");
})